# Battery Energy Storage System (BESS) Market Dataset

This package contains auto-generated structured files based on the public summary of the NextMSC BESS Market Report (EP3622).